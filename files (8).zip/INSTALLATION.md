# 📘 GUIDE D'INSTALLATION SIMPLE - Maneagritech IA Agent

## 🎯 MÉTHODE 1 : VERCEL (La Plus Simple - RECOMMANDÉE)

### ⏱️ Temps : 10 minutes | 💰 Coût : GRATUIT

### Étape 1 : Créer un compte Vercel

1. Allez sur **https://vercel.com**
2. Cliquez sur **"Sign Up"** (S'inscrire)
3. Choisissez **"Continue with GitHub"** (Continuer avec GitHub)
   - Si vous n'avez pas de compte GitHub :
     * Allez sur **https://github.com**
     * Créez un compte (gratuit)
     * Revenez sur Vercel et connectez-vous

### Étape 2 : Préparer votre projet

1. Téléchargez le dossier **maneagritech-agent** (ce dossier)
2. Créez un nouveau dépôt GitHub :
   - Allez sur GitHub.com
   - Cliquez sur le **"+"** en haut à droite
   - **"New repository"** (Nouveau dépôt)
   - Nom : `maneagritech-agent`
   - Cliquez **"Create repository"**

3. Uploadez les fichiers :
   - Cliquez sur **"uploading an existing file"**
   - Glissez tous les fichiers de ce dossier
   - Cliquez **"Commit changes"**

### Étape 3 : Déployer sur Vercel

1. Retournez sur **Vercel.com**
2. Cliquez sur **"Add New Project"** (Ajouter un nouveau projet)
3. Sélectionnez votre dépôt **maneagritech-agent**
4. Cliquez **"Deploy"** (Déployer)
5. Attendez 2-3 minutes... ✨

### 🎉 C'EST FAIT !

Vous recevrez un lien comme : **https://maneagritech-agent.vercel.app**

**C'est votre agent IA en ligne !** Partagez ce lien avec vos prospects.

---

## 🎯 MÉTHODE 2 : INSTALLATION LOCALE (Pour tester sur votre ordinateur)

### ⏱️ Temps : 15 minutes | 💻 Nécessite : Node.js

### Prérequis

1. **Installez Node.js** (si ce n'est pas déjà fait)
   - Allez sur **https://nodejs.org**
   - Téléchargez la version LTS (Long Term Support)
   - Installez-la (suivez les instructions)

### Installation

1. Ouvrez votre **Terminal** (Mac/Linux) ou **Invite de commandes** (Windows)

2. Naviguez vers le dossier du projet :
   ```bash
   cd chemin/vers/maneagritech-agent
   ```

3. Installez les dépendances :
   ```bash
   npm install
   ```
   (Cela prend 1-2 minutes)

4. Lancez l'application :
   ```bash
   npm run dev
   ```

5. Ouvrez votre navigateur et allez sur :
   **http://localhost:5173**

### 🎉 VOTRE AGENT FONCTIONNE !

Vous pouvez maintenant le tester localement.

---

## 🎯 MÉTHODE 3 : STACKBLITZ (Test Instantané - SANS INSTALLATION)

### ⏱️ Temps : 2 minutes | 💰 Gratuit | 🚀 Aucune installation

1. Allez sur **https://stackblitz.com**
2. Cliquez sur **"New Project"**
3. Sélectionnez **"React"**
4. Remplacez le contenu de `App.jsx` par le code dans `src/App.jsx`
5. Copiez aussi le contenu des autres fichiers si nécessaire

### 🎉 TEST IMMÉDIAT !

L'agent s'affiche directement dans votre navigateur.

---

## 📞 BESOIN D'AIDE ?

**Contactez-moi :**
- 📧 Email : ansoum78@gmail.com
- 📱 Téléphone : +221 76 693 43 13

---

## ✅ PROCHAINES ÉTAPES

Une fois déployé :

1. **Testez l'agent** - Posez-lui différentes questions
2. **Partagez le lien** - Envoyez-le à vos premiers prospects
3. **Personnalisez** - Demandez-moi d'ajuster le ton ou les questions
4. **Suivez les leads** - Surveillez votre email ansoum78@gmail.com

---

## 🎨 PERSONNALISATION

Vous voulez modifier :
- Les couleurs ?
- Le texte d'accueil ?
- Les packages proposés ?
- Les questions posées ?

**Contactez-moi et je vous aide gratuitement !**

---

© 2026 Maneagritech IA - Votre partenaire en automatisation intelligente
